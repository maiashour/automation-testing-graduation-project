package pages;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RegistrationPage extends PageBase {

	public RegistrationPage(WebDriver driver) {
		super(driver);

	}

	@FindBy(name = "name")
	WebElement usernameTxt;

	@FindBy(name = "email")
	List<WebElement> emails;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/form/button")
	WebElement signUpBtn;

	@FindBy(id = "id_gender1")
	WebElement maleGenderRadioBox;

	@FindBy(id = "password")
	WebElement passwordTxt;

	@FindBy(id = "days")
	WebElement daysList;

	@FindBy(id = "months")
	WebElement monthsList;

	@FindBy(id = "years")
	WebElement yearsList;

	@FindBy(id = "newsletter")
	WebElement newsLetterBtn;

	@FindBy(id = "optin")
	WebElement specialOfferBtn;

	@FindBy(id = "first_name")
	WebElement firstNameTxt;

	@FindBy(id = "last_name")
	WebElement lastNameTxt;

	@FindBy(id = "company")
	WebElement companyTxt;

	@FindBy(id = "address1")
	WebElement addressTxt1;

	@FindBy(id = "address2")
	WebElement addressTxt2;

	@FindBy(id = "country")
	WebElement countryList;

	@FindBy(id = "state")
	WebElement stateTxt;

	@FindBy(id = "city")
	WebElement cityTxt;

	@FindBy(id = "zipcode")
	WebElement zipcodeTxt;

	@FindBy(id = "mobile_number")
	WebElement mobileNumberTxt;

	@FindBy(css = "button.btn.btn-default")
	WebElement createAccountBtn;

	@FindBy(tagName = "b")
	WebElement Message;

	@FindBy(css = "a.btn.btn-primary")
	WebElement Continuebutton;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/form/p")
	WebElement validationmessage;

	@FindBy(tagName = "li")
	List<WebElement> navBarList;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/h2/b")
	public WebElement deleteMessage;

	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div[3]/div/form/p")
	public WebElement failedMessage;
	
	@FindBy(xpath ="//*[@id=\"form\"]/div/div/div[3]/div/h2")
	public WebElement newUserMessage;

	public void userCanRegister(String name, String email) {

		wait.until(ExpectedConditions.visibilityOf(usernameTxt)).sendKeys(name);
		wait.until(ExpectedConditions.visibilityOf(emails.get(1))).sendKeys(email);
		wait.until(ExpectedConditions.elementToBeClickable(signUpBtn)).click();

	}

	public void enterAccountInformation(String password, int day, String month, String year, String firstName,
			String lastName, String company, String address1, String address2, int countryIndex, String state,
			String city, String zipCode, String mobilNumber) {

		wait.until(ExpectedConditions.elementToBeClickable(maleGenderRadioBox)).click();
		wait.until(ExpectedConditions.visibilityOf(passwordTxt)).sendKeys(password);

		// maleGenderRadioBox.click();

		// passwordTxt.sendKeys("password");

		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("let days = document.getElementById('days')\r\n" + "days.scrollIntoView(\r\n" + "    {\r\n"
				+ "        behaviour: \"smooth\"\r\n" + "    }\r\n" + ")");

		Select makeDaysList = new Select(daysList);
		Select makeMonthsList = new Select(monthsList);
		Select makeYearsList = new Select(yearsList);
		Select makeCountryList = new Select(countryList);

		makeDaysList.selectByIndex(day);
		makeMonthsList.selectByVisibleText(month);
		makeYearsList.selectByValue(year);

		wait.until(ExpectedConditions.elementToBeClickable(newsLetterBtn)).click();

		wait.until(ExpectedConditions.elementToBeClickable(specialOfferBtn)).click();

		wait.until(ExpectedConditions.visibilityOf(firstNameTxt)).sendKeys(firstName);
		wait.until(ExpectedConditions.visibilityOf(lastNameTxt)).sendKeys(lastName);
		wait.until(ExpectedConditions.visibilityOf(companyTxt)).sendKeys(address1);
		wait.until(ExpectedConditions.visibilityOf(addressTxt1)).sendKeys(company);
		wait.until(ExpectedConditions.visibilityOf(addressTxt2)).sendKeys(address2);

		String title = (String) js.executeScript("return document.title;");
		System.out.println(title);

		js.executeScript("let country = document.getElementById('country')\r\n" + "country.scrollIntoView(\r\n"
				+ "    {\r\n" + "        behaviour: \"smooth\"\r\n" + "    }\r\n" + ")");

		makeCountryList.selectByIndex(0);
		wait.until(ExpectedConditions.visibilityOf(stateTxt)).sendKeys(state);
		wait.until(ExpectedConditions.visibilityOf(cityTxt)).sendKeys(city);

		wait.until(ExpectedConditions.visibilityOf(zipcodeTxt)).sendKeys(zipCode);
		wait.until(ExpectedConditions.visibilityOf(mobileNumberTxt)).sendKeys(mobilNumber);

		wait.until(ExpectedConditions.elementToBeClickable(createAccountBtn)).click();

	}

	public boolean getcontinuebutton() {
		return Continuebutton.isDisplayed();
	}

	public void clickoncontinue() {
		Continuebutton.click();
	}

	public void deleteAccount() {
		navBarList.get(4).click();
	}

	public String getAccountCreatedMessage() {
		return Message.getText();
	}

	public String getDuplicatedemailMessage() {
		return validationmessage.getText();
	}

}
