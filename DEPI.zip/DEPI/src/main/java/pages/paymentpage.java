package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class paymentpage extends PageBase {

	public paymentpage(WebDriver driver) {
		super(driver);
		
	}
	
	
	
	
	
	@FindBy(name="name_on_card")
	WebElement CardNametxt;
	
	@FindBy(name="card_number")
	WebElement CardNumbertxt;
	
	
	@FindBy(name="cvc")
	WebElement CVCtxt;
	
	@FindBy(name="expiry_month")
	WebElement ExpiryMonthtxt;
	
	@FindBy(name="expiry_year")
	WebElement ExpiryYeartxt;
	
	@FindBy(id="submit")
	WebElement submitbutton;
	
	@FindBy(xpath="//*[@id=\"form\"]/div/div/div/h2/b")
	WebElement SuccessMessage;
	
	
	@FindBy(css="a.btn.btn-default.check_out")
	WebElement Downloadinvoice;
	
	@FindBy(xpath = "(//div[@class='product-overlay'])[1]//a[contains(text(),'Add to cart')]")
    WebElement firstAddToCartBtn;
	
	 @FindBy(xpath = "(//div[@class='productinfo text-center'])[1]")
	    WebElement firstProductCard;
	 
	 @FindBy(xpath = "//button[contains(text(),'Continue Shopping')]")
	    WebElement continueShoppingBtn;
	 
	 
	 
	 @FindBy(xpath="//*[@id=\"do_action\"]/div[1]/div/div/a")
	 WebElement ProceedToCheckoutBtn;
	 
	 
	 @FindBy(linkText="Register / Login")
	 WebElement registerlink;
	 
	 @FindBy(xpath="//*[@id=\"cart_items\"]/div/div[7]/a")
	 WebElement placeorderbtn;
	 
	 
	 @FindBy(name="message")
	 WebElement ordercomment;
	 
	 
	 @FindBy(xpath="//*[@id=\"form\"]/div/div/div/div/a")
	 WebElement continuebtn;


	
	public void userselectproduct() {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scrollBy(0,2000)");
		
		        
		        Actions actions = new Actions(driver);
		        actions.moveToElement(wait.until(ExpectedConditions.visibilityOf(firstProductCard))).perform();
		        wait.until(ExpectedConditions.elementToBeClickable(firstAddToCartBtn)).click();
		        wait.until(ExpectedConditions.visibilityOf(continueShoppingBtn)).click();
		        
		        js.executeScript("window.scrollTo(0, 0);");
		       
		    }
	
	public void userproceedtocheckout()
	{
		 wait.until(ExpectedConditions.elementToBeClickable(ProceedToCheckoutBtn)).click();
	       
	}
	
	public void registercheck()
	{
		 wait.until(ExpectedConditions.elementToBeClickable(registerlink)).click();
	}
	
	public void placeorder(String orderComment)
	{

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scrollBy(0,2000)");
		wait.until(ExpectedConditions.visibilityOf(ordercomment)).sendKeys(orderComment);

		wait.until(ExpectedConditions.elementToBeClickable(placeorderbtn)).click();
	}
	
		

		
		
	
	
	
	public void UserCanPay(String Cardname ,String cardNo,String CVC , String expirymonth , String expiryyear) {
		wait.until(ExpectedConditions.visibilityOf(CardNametxt)).sendKeys(Cardname);
		wait.until(ExpectedConditions.visibilityOf(CardNumbertxt)).sendKeys(cardNo);
		wait.until(ExpectedConditions.visibilityOf(CVCtxt)).sendKeys(CVC);
		wait.until(ExpectedConditions.visibilityOf(ExpiryYeartxt)).sendKeys(expiryyear);
		wait.until(ExpectedConditions.visibilityOf(ExpiryMonthtxt)).sendKeys(expirymonth);
		wait.until(ExpectedConditions.elementToBeClickable(submitbutton)).click();
		
	
		
	}
	
	public String Getordermessage() {
		
		return SuccessMessage.getText();
	}
	
	public void downloadinvoiceandcontinue() {
		Downloadinvoice.click();
		wait.until(ExpectedConditions.elementToBeClickable(continuebtn)).click();
	}
	
}



