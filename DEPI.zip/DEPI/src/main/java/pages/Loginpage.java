package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class Loginpage extends PageBase {
    
	public Loginpage(WebDriver driver) {
		super(driver);
		
	}
	
	
	
	@FindBy(name="email")
	WebElement emailTxt;
	
	@FindBy(name="password")
	WebElement passwordTxt;

	
	@FindBy(xpath="//*[@id=\"form\"]/div/div/div[1]/div/form/button")
	WebElement loginbutton;
	
	@FindBy(xpath="//*[@id=\"form\"]/div/div/div[1]/div/h2")
	public WebElement loginMessage;
	
	@FindBy(xpath="//*[@id=\"header\"]/div/div/div/div[2]/div/ul/li[10]/a")
	WebElement loggedintext;
	
	@FindBy(linkText = "Logout")
	WebElement logoutBtn;
	
	@FindBy(linkText = "Delete Account")
	WebElement Deletebtn;
	
	
	@FindBy(css="#form > div > div > div.col-sm-4.col-sm-offset-1 > div.login-form > form > p")
	public WebElement failedMessage;
	
	@FindBy(xpath = "//*[@id=\"form\"]/div/div/div/h2")
	WebElement AccountDeletedMsg;
	
	
public void userCanlogin(String email,String password) {
	
	wait.until(ExpectedConditions.visibilityOf(emailTxt)).sendKeys(email);
    wait.until(ExpectedConditions.visibilityOf(passwordTxt)).sendKeys(password);
	wait.until(ExpectedConditions.elementToBeClickable(loginbutton)).click();
		
	}



public String loggedinlMessage() {
    return loggedintext.getText();
}

public String loginmessage() {
    return loginMessage.getText();
}


public void DeleteAccount() {
	wait.until(ExpectedConditions.elementToBeClickable(Deletebtn)).click();
}

public String getdeletedmsg() {
    return AccountDeletedMsg.getText();
}




	
}




