package tests;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.Loginpage;


public class Loginnegativescenario extends TestBase {
	HomePage homeObject = new HomePage(driver);
	Loginpage loginpage = new Loginpage(driver);
	WebDriverWait wait;
	 
	@DataProvider(name = "LoginInvalidData")
	public Object[][] testData() {
		Object[][] data = new Object[][] { { "maiashour9021188@gmail.com", "12345678912" }

		};

		return data;
	};

	
	
	
  @Test (dataProvider = "LoginInvalidData")
  public void usercannotlogin(String email, String password)  {
	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color")); ;
	  homeObject.openRegisterationPage();
	Assert.assertEquals("Login to your account", loginpage.loginmessage()); 
	 loginpage.userCanlogin(email, password);
	 
	 Assert.assertEquals("Your email or password is incorrect!", loginpage.failedMessage.getText());
  }
}
