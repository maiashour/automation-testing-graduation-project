package tests;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.RegistrationPage;

public class Registernegativescenairo  extends TestBase{
	
	HomePage homeobject = new HomePage(driver);
	RegistrationPage registerPage = new RegistrationPage(driver);
	String DuplicatedEmail = "Email Address already exist!";
	
	
	@DataProvider(name = "RegisterInvaliddata")
	public Object[][] testData() {
		Object[][] data = new Object[][] { {"maiashour","maiashourll22902@gmail.com"
		}

		};

		return data;
	};

  @Test(dataProvider = "RegisterInvaliddata")
  public void RegisterWithExistEmail (String name ,String email) {
	 
      homeobject.openRegisterationPage();
      Assert.assertEquals("New User Signup!", registerPage.newUserMessage.getText());
     registerPage.userCanRegister(name, email);
      assertEquals(registerPage.getDuplicatedemailMessage(), DuplicatedEmail);
  }
}
