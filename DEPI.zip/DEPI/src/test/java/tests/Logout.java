package tests;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.Loginpage;
import pages.Logoutpage;

public class Logout extends TestBase {
	 HomePage homeObject = new HomePage(driver);
	  Logoutpage logout = new Logoutpage (driver);
	  Loginpage loginpage = new Loginpage(driver);
	  
	  @DataProvider(name = "LoginData")
		public Object[][] testData() {
			Object[][] data = new Object[][] { { "marwaashour90211@gmail.com", "123456789" }

			};

			return data;
		};
	  
  @Test(dataProvider = "LoginData")
  public void usercanlogout(String email,String password) {
	  
		Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color"));
		homeObject.openRegisterationPage();
		Assert.assertEquals("Login to your account", loginpage.loginmessage());
		loginpage.userCanlogin(email, password);

		Assert.assertTrue(loginpage.loggedinlMessage().contains("Logged in as"));
		logout.userCanLogout();
		assertEquals(driver.getCurrentUrl(), "https://automationexercise.com/login");
		 
	  
  }
  
}
