package tests;
import static org.testng.Assert.assertEquals;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.Loginpage;
import pages.RegistrationPage; 

public class Registertesthappyscennario extends TestBase{


	HomePage homeObject = new HomePage(driver);

	RegistrationPage registerPage = new RegistrationPage(driver);
	String ActualMessage = "ACCOUNT CREATED!";
	

	@DataProvider(name = "Registerdata")
	public Object[][] testData() {
		Object[][] data = new Object[][] { { "MaiAshour", "maiashour11111@gmail.com","123456789",5,"May","1998","Mai",
			"Ashour","DEPI","Address Line1","Address Line2",1,"Statename","Giza","12345","001123456789"
		}

		};

		return data;
	};

	@Test(dataProvider = "Registerdata")
	public void UserCanRegister(String name ,String email ,String password, int day, String month, String year, String firstName,
			String lastName, String company, String address1, String address2, int countryIndex, String state,
			String city, String zipCode, String mobilNumber)  {

		homeObject.openRegisterationPage();
		 Assert.assertEquals("New User Signup!", registerPage.newUserMessage.getText());
		registerPage.userCanRegister(name,email);


		registerPage.enterAccountInformation( password, day, month, year,firstName,lastName,company,address1,address2,countryIndex,state,city,
				zipCode,mobilNumber
				);

		assertEquals(registerPage.getAccountCreatedMessage(), ActualMessage);
		assertEquals(registerPage.getcontinuebutton(),true);
		registerPage.clickoncontinue();
		Loginpage login = new Loginpage(driver);
		Assert.assertTrue(login.loggedinlMessage().contains("Logged in as"));

		login.DeleteAccount();
		Assert.assertTrue(login.getdeletedmsg().contains("ACCOUNT DELETED!"));

	}


}
