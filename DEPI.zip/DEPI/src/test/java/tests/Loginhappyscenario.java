package tests;

import java.time.Duration;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.Loginpage;

public class Loginhappyscenario extends TestBase {

	HomePage homeObject = new HomePage(driver);
	Loginpage loginpage = new Loginpage(driver);
	WebDriverWait wait;

	@DataProvider(name = "LoginData")
	public Object[][] testData() {
		Object[][] data = new Object[][] { { "maiashour@gmail.com", "12345" }

		};

		return data;
	};

	@Test(dataProvider = "LoginData")
	public void UsercanLogin(String email, String password) {
	    HomePage homeObject = new HomePage(driver);
	    Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color"));

	    homeObject.openRegisterationPage(); 

	    Loginpage loginpage = new Loginpage(driver); 

	    Assert.assertEquals("Login to your account", loginpage.loginmessage());

	    loginpage.userCanlogin(email, password);
	    Assert.assertTrue(loginpage.loggedinlMessage().contains("Logged in as"));

	    loginpage.DeleteAccount();
	    Assert.assertTrue(loginpage.getdeletedmsg().contains("ACCOUNT DELETED!"));
	}
}
