package tests;
import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.Loginpage;
import pages.paymentpage;
import pages.RegistrationPage;


public class Pay extends TestBase {
	HomePage homeObject = new HomePage(driver);
	Loginpage loginpage = new Loginpage(driver);
	String ActualMessage = "ORDER PLACED!";
	
	paymentpage pay = new paymentpage(driver);

	@DataProvider(name = "LoginData")
	public Object[][] testData() {
		Object[][] data = new Object[][] { { "maiashour@gmail.com", "12345" }

		};

		return data;
	};

	@DataProvider(name = "payment")
	public Object[][] paymenttestData() {
		Object[][] data = new Object[][] { { "Mai Ashour", "123456789", "123", "06", "2025" }

		};

		return data;
	};

	@Test(dataProvider = "LoginData")
	public void DownloadInvoiceafterpurchaseorder(String email, String password) {
		

		homeObject.openproductpage();
		pay.userselectproduct();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); 

		homeObject.opencartpage();
		pay.userproceedtocheckout();
	wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		pay.registercheck();
		loginpage.userCanlogin(email, password);
		homeObject.opencartpage();
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		pay.userproceedtocheckout();
		pay.placeorder("the description for comment");
	}

	@Test(dataProvider = "payment")
	public void userpay(String Cardname, String cardNo, String CVC, String expirymonth, String expiryyear) {
		pay.UserCanPay(Cardname, cardNo, CVC, expirymonth, expiryyear);
		assertEquals(pay.Getordermessage(), ActualMessage);
		pay.downloadinvoiceandcontinue();

	}

	
}
